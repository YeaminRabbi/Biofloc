<footer class="sl-footer">
    <div class="footer-left">
      <div class="mg-b-2">Copyright &copy; 2021. Biofloc. All Rights Reserved.</div>
      <div>Developed by Biofloc Team</div>
    </div>
</footer>